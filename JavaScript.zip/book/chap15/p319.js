const d = new Date();
console.log(d); // formatted Gregorian date with TZ
// 2018-09-12T06:54:38.431Z
console.log(d.valueOf()); // milliseconds since Unix Epoch
// 1536735278431