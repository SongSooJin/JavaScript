// let var1;
// let var2 = undefined;
// 
// console.log(var1); // undefined
// console.log(var2); // undefined
// 
// undefinedVar; // ReferenceError: notDefined is not defined
// 
// x; // ReferenceError: x is not defined
// let x = 3; // we'll never get here -- the error stops execution


console.log(x);

var x = 10;
var x = 20; // var 재 선언이 가능?!

console.log(x); // 20

let y = 10;
// let y = 20; // Let, const : 재 선언이 불가능 
