




(function() {
console.log(x);

  var x = 10;
  var x = 20;

console.log(x);

// console.log(y); // TDZ

  let y = 100;
  
console.log(y);
}());