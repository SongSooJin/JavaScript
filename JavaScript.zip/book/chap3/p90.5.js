
// 자바의 방법 
// class A {
//   int a = 10;
//   B b = new B();
// }
// 
// class B {
//   String c = "Hi";
// }

// 자바스크립트 방법 
var obj = {
  a: 10,
  b: {
    c: "Hi"
  }
};