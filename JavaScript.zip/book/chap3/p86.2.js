console.log(3+'30');  // 330   
console.log(3*'30');  // 90
console.log(3-'30');  // -27
console.log(3/'30');  // 10

console.log(3 * '삼십'); // NaN

var a = 10;
var b = null; // null
var c;  // undefined

// null : 명시적으로 개발자가 값 없다고 선언!
// undefined : 묵시적으로 값이 없는 상태  