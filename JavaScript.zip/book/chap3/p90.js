var obj = {a:10};
obj.a = 20;

console.log(obj);

const obj2 = {a:10};
obj2.a = 20;

console.log(obj2);

