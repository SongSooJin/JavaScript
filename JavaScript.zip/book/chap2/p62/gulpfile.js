/*
반복적인 작업을 설정하여 Gulp를 통해 작업을 수행합니다.
*/

const gulp = require('gulp');
// 걸프 의존성을 여기에 쓴다
gulp.task('default',function () {
// 걸프 작업을 여기 쓴다.
});