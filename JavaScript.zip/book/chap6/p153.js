const skipIt = "사용자가 입력한 문자열";
let x = 0;
const result = skipIt || x++;

console.log(x,result);