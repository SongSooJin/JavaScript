// 함수 선언식
function add() {
  return 1;
}

console.log(add());

// 함수 표현식
var adder = function() { // 익명 함수 
  return 2;
};

console.log(adder());