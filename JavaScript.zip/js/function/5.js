var a = "10";
var b = "10";
var c = "20";

console.log(a == b);
console.log(a == c);

console.log("---------------");
/*
비교연산자 2가지
*/

console.log(a === b);
console.log(a === c);

console.log("---------------");

// == 비교연산자는 숫자를 문자열로 캐스팅하여 비교한다.

console.log(10 == "10");
console.log(10 === "10");
